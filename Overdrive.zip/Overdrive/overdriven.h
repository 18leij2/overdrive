// overdriven sound made by wav2c

extern const unsigned int overdriven_sampleRate;
extern const unsigned int overdriven_length;
extern const signed char overdriven_data[];

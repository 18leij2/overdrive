// swordhit sound made by wav2c

extern const unsigned int swordhit_sampleRate;
extern const unsigned int swordhit_length;
extern const signed char swordhit_data[];

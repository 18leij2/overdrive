// wintheme sound made by wav2c

extern const unsigned int wintheme_sampleRate;
extern const unsigned int wintheme_length;
extern const signed char wintheme_data[];

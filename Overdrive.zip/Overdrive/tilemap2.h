#ifndef TILEMAP2_H
#define TILEMAP2_H

#define TILEMAP2_WIDTH  (128)
#define TILEMAP2_HEIGHT (32)
#define tilemap2MapLen (8192)

extern const unsigned short tilemap2Map[4096];

#endif

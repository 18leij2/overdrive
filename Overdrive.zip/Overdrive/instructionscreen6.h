
//{{BLOCK(instructionscreen6)

//======================================================================
//
//	instructionscreen6, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 351 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 11232 + 2048 = 13792
//
//	Time-stamp: 2023-04-25, 06:53:54
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_INSTRUCTIONSCREEN6_H
#define GRIT_INSTRUCTIONSCREEN6_H

#define instructionscreen6TilesLen 11232
extern const unsigned short instructionscreen6Tiles[5616];

#define instructionscreen6MapLen 2048
extern const unsigned short instructionscreen6Map[1024];

#define instructionscreen6PalLen 512
extern const unsigned short instructionscreen6Pal[256];

#endif // GRIT_INSTRUCTIONSCREEN6_H

//}}BLOCK(instructionscreen6)

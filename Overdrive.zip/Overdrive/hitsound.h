// hitsound sound made by wav2c

extern const unsigned int hitsound_sampleRate;
extern const unsigned int hitsound_length;
extern const signed char hitsound_data[];

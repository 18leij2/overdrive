// losetheme sound made by wav2c

extern const unsigned int losetheme_sampleRate;
extern const unsigned int losetheme_length;
extern const signed char losetheme_data[];

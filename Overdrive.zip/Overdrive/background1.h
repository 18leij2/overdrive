
//{{BLOCK(background1)

//======================================================================
//
//	background1, 512x256@4, 
//	+ palette 256 entries, not compressed
//	+ 49 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 64x32 
//	Total size: 512 + 1568 + 4096 = 6176
//
//	Time-stamp: 2023-04-20, 21:26:12
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_BACKGROUND1_H
#define GRIT_BACKGROUND1_H

#define background1TilesLen 1568
extern const unsigned short background1Tiles[784];

#define background1MapLen 4096
extern const unsigned short background1Map[2048];

#define background1PalLen 512
extern const unsigned short background1Pal[256];

#endif // GRIT_BACKGROUND1_H

//}}BLOCK(background1)

// swordstab sound made by wav2c

extern const unsigned int swordstab_sampleRate;
extern const unsigned int swordstab_length;
extern const signed char swordstab_data[];

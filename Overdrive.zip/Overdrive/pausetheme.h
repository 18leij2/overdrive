// pausetheme sound made by wav2c

extern const unsigned int pausetheme_sampleRate;
extern const unsigned int pausetheme_length;
extern const signed char pausetheme_data[];

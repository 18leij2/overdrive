// buttons sound made by wav2c

extern const unsigned int buttons_sampleRate;
extern const unsigned int buttons_length;
extern const signed char buttons_data[];


//{{BLOCK(collisionmap2)

//======================================================================
//
//	collisionmap2, 1024x256@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 262144 = 262656
//
//	Time-stamp: 2023-04-12, 11:00:24
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_COLLISIONMAP2_H
#define GRIT_COLLISIONMAP2_H

#define collisionmap2BitmapLen 262144
extern const unsigned short collisionmap2Bitmap[131072];

#define collisionmap2PalLen 512
extern const unsigned short collisionmap2Pal[256];

#endif // GRIT_COLLISIONMAP2_H

//}}BLOCK(collisionmap2)

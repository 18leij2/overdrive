// demonmode sound made by wav2c

extern const unsigned int demonmode_sampleRate;
extern const unsigned int demonmode_length;
extern const signed char demonmode_data[];

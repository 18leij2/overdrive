<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="tileset" tilewidth="8" tileheight="8" tilecount="1024" columns="32">
 <image source="tileset.bmp" width="256" height="256"/>
</tileset>

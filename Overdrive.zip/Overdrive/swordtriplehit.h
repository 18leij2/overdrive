// swordtriplehit sound made by wav2c

extern const unsigned int swordtriplehit_sampleRate;
extern const unsigned int swordtriplehit_length;
extern const signed char swordtriplehit_data[];

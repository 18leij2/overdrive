#ifndef TILEMAP_H
#define TILEMAP_H

#define TILEMAP_WIDTH  (32)
#define TILEMAP_HEIGHT (32)
#define tilemapMapLen (2048)

extern const unsigned short tilemapMap[1024];

#endif

// menutheme sound made by wav2c

extern const unsigned int menutheme_sampleRate;
extern const unsigned int menutheme_length;
extern const signed char menutheme_data[];
